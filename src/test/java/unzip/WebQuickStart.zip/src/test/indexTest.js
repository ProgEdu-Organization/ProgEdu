const {
  Builder, By,
} = require('selenium-webdriver');
const path = require('path');

(async function example() {
  const driver = new Builder().forBrowser('chrome').usingServer('http://140.134.26.71:4444/wd/hub').build();
  const dirPathNum = path.resolve(__dirname).split('/').indexOf('src') - 1;
  try {
    console.log('dir: ' + path.resolve(__dirname));
    console.log('dirPathNum: ' + dirPathNum);
    console.log('dirPath: ' + 'file://' + '/var/lib/workspace/' + path.resolve(__dirname).split('/')[dirPathNum] + '/src/web/html/index.html');
    // eslint-disable-next-line no-useless-concat
    await driver.get('file:///' + '/var/lib/workspace/' + path.resolve(__dirname).split('/')[dirPathNum] + '/src/web/html/index.html');
    await driver.findElement(By.xpath("//form[@name='loginForm123']/input[@name='username']")).sendKeys('123');
    await driver.findElement(By.xpath("//form[@name='loginForm123']/input[@name='password']")).sendKeys('123');
    await driver.findElement(By.xpath("//form[@name='loginForm123']/input[@name='continue']")).click();
    await driver.findElement(By.id('title'));
  } finally {
    await driver.quit();
  }
}());
