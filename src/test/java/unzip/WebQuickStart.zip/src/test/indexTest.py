import time
import os
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import selenium.webdriver.support.ui as ui
import os.path

driver = webdriver.Remote(
    command_executor='http://140.134.26.71:4444/wd/hub',
    desired_capabilities=DesiredCapabilities.CHROME
)

root_dir = os.path.dirname(os.path.abspath("indexTest.py"))

driver.get("file:///" + "/var/lib/workspace/" + root_dir.split('/')[4] + "/src/web/html/index.html")

assert driver.find_element_by_tag_name('h1'), '元素不存在'

time.sleep(2)
driver.quit()  # 關閉 chromedriver
