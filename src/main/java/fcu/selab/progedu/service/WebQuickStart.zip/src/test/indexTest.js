/*eslint-disable */
const {
  Builder,
  By,
  Key,
  until
} = require('selenium-webdriver');
const {
  expect
} = require('chai');
const path = require('path');

describe('DefaultTest', () => {
  const driver = new Builder().forBrowser('chrome').usingServer('http://140.134.26.71:4444/wd/hub').build();
  const dirPathNum = path.resolve(__dirname).split('/').indexOf('src') - 1;

  it('Sample test case', async () => {
    await driver.get('file:///' + '/var/lib/workspace/' + path.resolve(__dirname).split('/')[dirPathNum] + '/src/web/html/index.html');
    await driver.findElement(By.xpath("//form[@name='loginForm123']/input[@name='username']")).sendKeys('123');
    await driver.findElement(By.xpath("//form[@name='loginForm123']/input[@name='password']")).sendKeys('123');
    await driver.findElement(By.xpath("//form[@name='loginForm123']/input[@name='continue']")).click();
    const title = await driver.getTitle();
    expect(title).to.equal('HelloWorld');
  });

  after(async () => driver.quit());
});