package selab.myapp;

/**
 * Hello world!
 *
 */
public class App {
  public String sayHello() {
    String hello = "Hello World!";
    return hello;
  }
}
