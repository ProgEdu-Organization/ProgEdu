from src.plus import plus


if __name__ == '__main__':
    print(plus(1, 2))
    print(plus(2, 2))
