from src.plus import plus


def test():
    assert 3 == plus(1, 2)
    assert 6 == plus(4, 2)
