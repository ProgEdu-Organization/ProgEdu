/*eslint-disable */
const {Builder, By} = require('selenium-webdriver');
const path = require('path');
const fs = require('fs');

const seleniumServer = process.env.WEB_SELENIUM_URL + '/wd/hub'; //輸入課程使用的Selenium server url
const driver = new Builder().forBrowser('chrome').usingServer(seleniumServer).build(); //使用chrome browser來測試Web作業


if(!fs.existsSync("target")){
    fs.mkdirSync("target", 0766, function(err){
        if(err){
            console.log(err);
            // echo the result back
            response.send("ERROR! Can't make the directory! \n");
        }
    });

    if(!fs.existsSync("target/screenshot")){
        fs.mkdirSync("target/screenshot", 0766, function(err){
            if(err){
                console.log(err);
                // echo the result back
                response.send("ERROR! Can't make the directory! \n");
            }
        });
    }

}



const htmlFolder = './src/web/html/';
fs.readdir(htmlFolder, (err, files) => {
    files.forEach((file,index) => {
      let htmlUrl = 'http://docker:' + process.env.WEB_PORT + '/' + file;
      screenShot(htmlUrl);

      if(index === files.length - 1) {
        driver.quit();
      }

    });
});

function screenShot(httpUrl) {
    
    driver.get(httpUrl);
    let fileNamePos = httpUrl.lastIndexOf("/");
    let fileName = httpUrl.substring( fileNamePos + 1 );  

    driver.takeScreenshot().then(
        function(image, err) {
            require('fs').writeFile( "./target/screenshot/" + fileName + '.png', image, 'base64', function(err) {
                console.log(err);
            });
        }
    );
}

