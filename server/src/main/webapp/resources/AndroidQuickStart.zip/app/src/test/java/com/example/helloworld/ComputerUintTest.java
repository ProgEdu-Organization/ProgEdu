package com.example.helloworld;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ComputerUintTest {
    Computer computer = new Computer();
    int [] num ={10, 100, 50};

    @Test
    public void isCorrect_getMax(){
        assertEquals( computer.getMax(num), 100);
        System.out.print("Computer Sul");
    }
}
