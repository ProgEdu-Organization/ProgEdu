package com.example.helloworld;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;
import android.widget.TextView;
import com.squareup.spoon.Spoon;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.io.OutputStream;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static org.junit.Assert.assertEquals;

;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    @Rule
    public ActivityTestRule<MainActivity> mActivityRule = new ActivityTestRule(MainActivity.class);
    @Test
    public void useAppContext() throws Exception {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();
        TextView text= (TextView) mActivityRule.getActivity().findViewById(R.id.text);

        assertEquals("com.example.helloworld", appContext.getPackageName());
        assertEquals("Hello World!", text.getText());

        Spoon.screenshot( mActivityRule.getActivity(), "Test0");

        onView(withId(R.id.button)) // Matcher
                .perform(click()); // Action
        Spoon.screenshot( mActivityRule.getActivity(), "Test1");
        //screenShot();
        assertEquals("1600", text.getText());
    }

    public void screenShot() throws IOException, InterruptedException {
        Log.v("stage1","test");
        Process sh = Runtime.getRuntime().exec("su");
        OutputStream os = sh.getOutputStream();
        Log.v("stage2","test");
        os.write(("screencap -p /sdcard/Pictures/test").getBytes());
        Log.v("stage3","test");
        os.flush();
        os.close();
        sh.waitFor();
    }
}