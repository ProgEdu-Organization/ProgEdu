請先至[SideeX官網](https://sideex.io/download/)下載SideeX Recorder並安裝至Chrome瀏覽器
錄製完成後請將test suite輸出成JSON檔並命名為"testSuite.json"然後儲存到此專案的test目錄底下，再打包上傳到ProgEdu。